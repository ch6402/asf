#include <iostream>
#include "HeapSort.h"
using namespace std;

int main()
{
	int a[100];
	a[0] = 25;
	a[1] = 17;
	a[2] = 36;
	a[3] = 2;
	a[4] = 3;
	a[5] = 100;
	a[6] = 1;
	a[7] = 19;
	a[8] = 7;

	HeapSort(a, 9);

	return 0;
}